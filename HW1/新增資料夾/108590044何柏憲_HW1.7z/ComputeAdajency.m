function [ labels ] = ComputeAdajency( x , csvPath )
    inputArray = csvread(csvPath);
    disp('inputArray=');
    disp(inputArray);
    
    if x == 4
        [ans,labels] = bwlabel(inputArray,4);
    else
        [ans,labels] = bwlabel(inputArray,8);
    end
    disp('ans=');
    disp(ans);
end
    
